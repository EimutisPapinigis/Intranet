<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<?php require_once('db.php');
 if(isset($_POST['submit']))
{ 
 $time = date("g:i:s A");
 $date = date("n/j/Y"); 
  
 $vardaspavarde=$_POST['fvp'];
 $tortadienis=$_POST['ftortadienis'];
 $gdiena=$_POST['fgdiena'];
 $pareigos=$_POST['fpareigos'];
 $result = ""; 
 
 if(!empty($vardaspavarde) && !empty($tortadienis)&& !empty($gdiena)&& !empty($pareigos)) 
	{ 
		
		$query = "INSERT INTO gimtadieniai (";
		$query .= " Vardas_Pavarde, Tortadienis, Gimimo_diena, Pareigos";
		$query .= ") VALUES (";
		$query .= " '{$vardaspavarde}', '{$tortadienis}', '{$gdiena}', '{$pareigos}' "; 
		$query .= ")";
		$result = mysqli_query($connect, $query); 
		header("location: gimtadieniai.php");
		
		
	}
} 	
?>


<!DOCTYPE html>
<html><!--$result->fetch_assoc();-->
<head>
	<title>Pridėti gimtadienį</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>

<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p>Sveiki, <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.php?logout='1'" style="color: red;">atsijungti</a> </p>
    <?php endif ?>
</div>
<style type="text/css">
textarea 
{ 
border-radius: 2%; 
} 
#thread 
{ 
border: 1px #d3d3d3 solid;
height: 350px; width: 350px; overflow: scroll;
}

div.nav-bar {border-style: ridge;}
a.nav-bar-item-nav-button {
  border-style: solid;
  border-width: medium;
}
div.Left-side 
{
	border-style: solid;
	border-color: green;
}
div.Right-side 
{
	border-style: solid;
	border-color: green;
}

</style>
		<div class="nav-card-2 topnav notranslate" id="topnav" style="position= relative;">
  <div>
    <div class="nav-bar" style="background-color:powderblue;">
      <a class="nav-bar-item-nav-button active" href="index.php" title="Pradžia">Pradžia</a>
      <a class="nav-bar-item-nav-button" href="" title="Registras">Registras</a>
      <a class="nav-bar-item-nav-button" href="" title="KVS Programa">KVS Programa</a>
      <a class="nav-bar-item-nav-button" href="" title="Užsakymų archyvas">Užsakymų archyvas</a>
      <a class="nav-bar-item-nav-button" href="" title="Tikslangai">Tikslangai</a>
      <a class="nav-bar-item-nav-button" href="" title="PVC apkrovimo grafikas">PVC apkrovimo grafikas</a>
      <a class="nav-bar-item-nav-button" href="" title="Spec. Pvc apkrovimo grafikas">Spec. Pvc apkrovimo grafikas</a>
      <a class="nav-bar-item-nav-button" href="login.php" title="SOS prisijungimas">SOS prisijungimas</a>
    </div>
  </div>
</div>
</head>
<body>
<div style="width: 100%; display: table;">
    <div style="display: table-row">
        <div class="Left-side" style="width: 250px; display: table-cell;">
		<div>
		<h2>Dokumentai</h2>
		<a class="dokumentai-link" href="direktoriaus.php" title="Direktoriaus įsakymai">Direktoriaus įsakymai</a>
		</br>
		<a class="dokumentai-link" href="tarnybiniai.php" title="Tarnybiniai nurodymai">Tarnybiniai nurodymai</a>
		</br>
		<a class="dokumentai-link" href="kvs.php" title="KVS dokumentai">KVS dokumentai</a>
		</br>
		<a class="dokumentai-link" href="išorės.php" title="Išorės dokumentai">Išorės dokumentai</a>
		</br>
		<a class="dokumentai-link" href="bendri.php" title="Bendri dokumentai">Bendri dokumentai</a>
		</div>
		<div>
		<h2>Įvairūs</h2>
		<a class="link" href="" title="Anoniminis forumas (Diskusijos)">Anoniminis forumas (Diskusijos)</a>
		</br>
		<a class="link" href="" title="Atstovai ir Tiekimas">Atstovai ir Tiekimas</a>
		</br>
		<a class="link" href="" title="Atstovų kontaktai">Atstovų kontaktai</a>
		</br>
		<a class="link" href="gimtadieniai.php" title="Gimtadieniai">Gimtadieniai</a>
		</br>
		<a class="link" href="darbuotojai.php" title="Darbuotojai">Darbuotojai</a>
		</br>
		<a class="link" href="" title="Išvykimo žiniaraštis">Išvykimo žiniaraštis</a>
		</br>
		<a class="link" href="" title="Konferencijų salės rezervavimas">Konferencijų salės rezervavimas</a>
		</br>
		<a class="link" href="kontaktai.php" title="Kontaktai">Kontaktai</a>
		</br>
		<a class="link" href="" title="Skundų registravimas">Skundų registravimas</a>
		</br>
		<a class="link" href="" title="Sutarčių kainų nunulinimo, atregistravimo, žymens koregavimo forma">Sutarčių kainų nunulinimo, atregistravimo, žymens koregavimo forma</a>
		</br>
		<a class="link" href="" title="Sutarčių terminų keitimo forma">Sutarčių terminų keitimo forma</a>
		</br>
		<a class="link" href="" title="Teorinio mokymo žurnalas">Teorinio mokymo žurnalas</a>
		</br>
		<a class="link" href="" title="VVS klaidos/pasiūlimai">VVS klaidos/pasiūlimai</a>
		</br>
		<a class="link" href="" title="VVs'o neatitikčių numeriai Registre">VVs'o neatitikčių numeriai Registre</a>
		</div>
		</div>
        <div class="Right-side" style="display: table-cell;">
		<form method="POST" action="gimtadieniai_pridėti.php">
		<label for="fvp">Vardas Pavardė:</label>
		<input type="text" name="fvp" id="fvp"><br>
		<label for="tortadienis">Tortadienis.:</label>
		<input type="date" name="ftortadienis" id="ftortadienis"><br>
		<label for="gdiena">Gimimo diena:</label>
		<input type="date" name="fgdiena" id="fgdiena"><br>
		<label for="pareigos">Pareigos:</label>
		<input type="text" name="fpareigos" id="fpareigos"><br>
		<button type="submit" name="submit">Pridėti</button>
		
		</form>
		</div>
    </div>
</div>
</body>
</html>