<?php
/**
 * Class Settings holds the upload settings
 *
 */
class Settings
{
	static $uploadFolder = "uploads/";
}
?>