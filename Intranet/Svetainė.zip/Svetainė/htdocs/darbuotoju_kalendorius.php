<html class="lang-lt " lang="lt">
<head>   
<link href="calendar.css" type="text/css" rel="stylesheet" />
<meta charset="utf-8">
</head>
<body>
<div>
		<form width="100%" method="POST" action="darbuotoju_kalendorius.php">
		<p>Pasirinkti darbuotoją</p>
		<input autocomplete="off" id="fpasirinkti" name="fpasirinkti"type="text" list="suggestions" size="80px" id="pasirinkimas" 
		placeholder="Vardas Pavardė. Pareigos. Miestas">
		<datalist id="suggestions">
	<?php	require_once('db.php');
	$sql = "SELECT * FROM darbuotojai";
	$result = mysqli_query($connect, $sql);
	foreach ($result as $row) {
		echo "<option>";
		echo $row['Vardas_Pavarde'].";".$row['Pareigos'].";".$row['Miestas'];
		echo "</option>";
	}
	?>
	
		</datalist>
		<button type="submit" name="submit">Submit</button>
		</form>
		</div>
		<?php
include 'dcalendar.php';

if(isset($_POST['submit']))
{
$pasirinti="";
$pasirinti=$_POST['fpasirinkti'];
$calendar = new Calendar($pasirinti);
//$calendar = new Calendar();
echo $calendar->show();
}
?>
</body>
</html>    