<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>	
<?php 
//Load the settings
require_once("settings.php");

$message = "";

//Has the user uploaded something?
if(isset($_FILES['file']))
{
	$target_path = "uploads2/";
	$target_path = $target_path . time() . '_' . basename( $_FILES['file']['name']);


	
	//Try to move the uploaded file into the designated folder
		if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
		    $message = "The file ".  basename( $_FILES['file']['name']). 
		    " has been uploaded";
		} 
		else{
		    $message = "There was an error uploading the file, please try again!";
		}
	
}
if(strlen($message) > 0)
{
	$message = '<p class="error">' . $message . '</p>';
}
/** LIST UPLOADED FILES **/
$uploaded_files = "";

//Open directory for reading
$dh = opendir("uploads2/");

//LOOP through the files
while (($file = readdir($dh)) !== false) 
{
	
	if($file != '.' && $file != '..')
	{
		
		$filename = "uploads2/" . $file;
		$parts = explode("_", $file);
		
		$size = formatBytes(filesize($filename));
		$added = date("m/d/Y", $parts[0]);
		$origName = $parts[1];
		$filetype = getFileType(substr($file, strlen($file) - 3));
		
        $uploaded_files .= "<li class=\"$filetype\">$filetype <a href=\"$filename\"> $origName</a> $size - $added</li>\n </br>";


	}
}
closedir($dh);

if(strlen($uploaded_files) == 0)
{
	$uploaded_files = "<li><em>No files found</em></li>";
}
function getFileType($extension)
{
	$images = array('jpg', 'gif', 'png', 'bmp', 'PNG');
	$docs 	= array('txt', 'rtf', 'doc');
	$apps 	= array('zip', 'rar', 'exe', '.7z');
	
	if(in_array($extension, $images)) return "Images";
	elseif(in_array($extension, $docs)) return "Documents";
	elseif(in_array($extension, $apps)) return "Applications";
	else return "File";
	return "";
}

function formatBytes($bytes, $precision = 2) { 
    $units = array('B', 'KB', 'MB', 'GB', 'TB'); 
   
    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 
   
    $bytes /= pow(1024, $pow); 
   
    return round($bytes, $precision) . ' ' . $units[$pow]; 
} 

?>



<!DOCTYPE html>
<html>
<head>
	<title>Įkelti failą</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
	<style type="text/css" media="all"> 
	@import url("style/style.css");
</style>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
</head>
<body>


<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p>Sveiki, <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.php?logout='1'" style="color: red;">atsijungti</a> </p>
    <?php endif ?>
</div>
<style type="text/css">
textarea 
{ 
border-radius: 2%; 
} 
#thread 
{ 
border: 1px #d3d3d3 solid;
height: 350px; width: 350px; overflow: scroll;
}

div.nav-bar {border-style: ridge;}
a.nav-bar-item-nav-button {
  border-style: solid;
  border-width: medium;
}
div.Left-side 
{
	border-style: solid;
	border-color: green;
}
div.Right-side 
{
	border-style: solid;
	border-color: green;
}

</style>
		<div class="nav-card-2 topnav notranslate" id="topnav" style="position= relative;">
  <div>
    <div class="nav-bar" style="background-color:powderblue;">
      <a class="nav-bar-item-nav-button active" href="index.php" title="Pradžia">Pradžia</a>
      <a class="nav-bar-item-nav-button" href="" title="Registras">Registras</a>
      <a class="nav-bar-item-nav-button" href="" title="KVS Programa">KVS Programa</a>
      <a class="nav-bar-item-nav-button" href="" title="Užsakymų archyvas">Užsakymų archyvas</a>
      <a class="nav-bar-item-nav-button" href="" title="Tikslangai">Tikslangai</a>
      <a class="nav-bar-item-nav-button" href="" title="PVC apkrovimo grafikas">PVC apkrovimo grafikas</a>
      <a class="nav-bar-item-nav-button" href="" title="Spec. Pvc apkrovimo grafikas">Spec. Pvc apkrovimo grafikas</a>
      <a class="nav-bar-item-nav-button" href="login.php" title="SOS prisijungimas">SOS prisijungimas</a>
    </div>
  </div>
</div>
</head>
<body>
<div style="width: 100%; display: table;">
    <div style="display: table-row">
        <div class="Left-side" style="width: 250px; display: table-cell;">
		<div>
		<h2>Dokumentai</h2>
		<a class="dokumentai-link" href="direktoriaus.php" title="Direktoriaus įsakymai">Direktoriaus įsakymai</a>
		</br>
		<a class="dokumentai-link" href="tarnybiniai.php" title="Tarnybiniai nurodymai">Tarnybiniai nurodymai</a>
		</br>
		<a class="dokumentai-link" href="kvs.php" title="KVS dokumentai">KVS dokumentai</a>
		</br>
		<a class="dokumentai-link" href="išorės.php" title="Išorės dokumentai">Išorės dokumentai</a>
		</br>
		<a class="dokumentai-link" href="bendri.php" title="Bendri dokumentai">Bendri dokumentai</a>
		</div>
		<div>
		<h2>Įvairūs</h2>
		<a class="link" href="" title="Anoniminis forumas (Diskusijos)">Anoniminis forumas (Diskusijos)</a>
		</br>
		<a class="link" href="" title="Atstovai ir Tiekimas">Atstovai ir Tiekimas</a>
		</br>
		<a class="link" href="" title="Atstovų kontaktai">Atstovų kontaktai</a>
		</br>
		<a class="link" href="gimtadieniai.php" title="Gimtadieniai">Gimtadieniai</a>
		</br>
		<a class="link" href="darbuotojai.php" title="Darbuotojai">Darbuotojai</a>
		</br>
		<a class="link" href="" title="Išvykimo žiniaraštis">Išvykimo žiniaraštis</a>
		</br>
		<a class="link" href="" title="Konferencijų salės rezervavimas">Konferencijų salės rezervavimas</a>
		</br>
		<a class="link" href="kontaktai.php" title="Kontaktai">Kontaktai</a>
		</br>
		<a class="link" href="" title="Skundų registravimas">Skundų registravimas</a>
		</br>
		<a class="link" href="" title="Sutarčių kainų nunulinimo, atregistravimo, žymens koregavimo forma">Sutarčių kainų nunulinimo, atregistravimo, žymens koregavimo forma</a>
		</br>
		<a class="link" href="" title="Sutarčių terminų keitimo forma">Sutarčių terminų keitimo forma</a>
		</br>
		<a class="link" href="" title="Teorinio mokymo žurnalas">Teorinio mokymo žurnalas</a>
		</br>
		<a class="link" href="" title="VVS klaidos/pasiūlimai">VVS klaidos/pasiūlimai</a>
		</br>
		<a class="link" href="" title="VVs'o neatitikčių numeriai Registre">VVs'o neatitikčių numeriai Registre</a>
		</div>
		</div>
        <div class="Right-side" style="display: table-cell;">
		<div id="container">

	
		<legend>Įkelti nauja failą</legend>
		<form method="post" action="tarnybiniai.php" enctype="multipart/form-data">
		<input type="hidden" name="MAX_FILE_SIZE" value="10000000" />
		<p><label for="name">Pasirinkti failą</label><br />
		<input type="file" name="file" /></p>
		<p><input type="submit" name="submit" value="Pridėti" /></p>
		</form>	
	
	
</div>
 
		</div>
    </div>
</div>
<script src="js/filestorage.js" />
</body>
</html>