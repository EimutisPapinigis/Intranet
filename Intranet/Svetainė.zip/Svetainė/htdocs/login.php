<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Prisijungimas</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Prisijungti</h2>
  </div>
	 
  <form method="post" action="login.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Naudotojo vardas</label>
  		<input type="text" name="username" >
  	</div>
  	<div class="input-group">
  		<label>Slaptažodis</label>
  		<input type="password" name="password">
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Prisijungti</button>
  	</div>
  	<p>
  		Naujas vartotojas? <a href="register.php">Užsiregistruoti</a>
  	</p>
  </form>
</body>
</html>